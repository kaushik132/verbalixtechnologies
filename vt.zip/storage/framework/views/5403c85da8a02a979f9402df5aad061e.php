
<?php $__env->startSection('main-containers'); ?>


        <!-- Header Start -->
        <div class="container-fluid bg-breadcrumb" style="background-image: url(../uploads/<?php echo e($banner['banner'], false); ?>)">
         <div class="container text-md-start text-center py-5">
             <h4 class="text-white display-4 mb-4 wow fadeInDown" data-wow-delay="0.1s">Our Services</h4>
             <ol class="breadcrumb d-flex mb-0 wow fadeInDown" data-wow-delay="0.3s">
                 <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                 <li class="breadcrumb-item"><a href="#">Pages</a></li>
                 <li class="breadcrumb-item active text-white">Service</li>
             </ol>    
         </div>
     </div>
     <!-- Header End -->


     <!-- Service Start -->
     <div class="container-fluid service py-5">
         <div class="container py-5">
             <div class="text-center mx-auto pb-5 wow fadeInUp" data-wow-delay="0.2s" style="max-width: 800px;">
                 <h4 class="text-primary">Our Services</h4>
                 <h1 class="display-4 mb-4">We Provide Best Services</h1>
                 <p class="mb-0">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Tenetur adipisci facilis cupiditate recusandae aperiam temporibus corporis itaque quis facere, numquam, ad culpa deserunt sint dolorem autem obcaecati, ipsam mollitia hic.
                 </p>
             </div>


             <div class="text-end mb-5">
                <div class="dropdown w-100">
                    <button class="btn btn-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                     Filter
                    </button>
                    <ul class="dropdown-menu">
                      <li><a class="dropdown-item" href="#">Action</a></li>
                      <li><a class="dropdown-item" href="#">Another action</a></li>
                      <li><a class="dropdown-item" href="#">Something else here</a></li>
                    </ul>
                  </div>
            </div>
             <div class="row g-4 justify-content-center">


                <?php $__currentLoopData = $servicesList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servicesList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
               
         
                 <div class="col-md-6 col-lg-6 col-xl-3 wow fadeInUp" data-wow-delay="0.4s">
                     <div class="service-item">
                         <div class="service-img">
                            <img src="<?php echo e(url('uploads/' . $servicesList->image), false); ?>" class="img-fluid rounded-top w-100" alt="">

                             <div class="service-icon p-3">
                                 <i class="fa fa-database fa-2x"></i>
                             </div>
                         </div>
                         <div class="service-content p-4">
                             <div class="service-content-inner">
                                 <a href="<?php echo e(url('service-details/'.$servicesList->slug), false); ?>" class="d-inline-block h4 mb-4"><?php echo e($servicesList->title, false); ?></a>
                                 <p class="mb-4"><?php echo e($servicesList->short_content, false); ?></p>
                                 <a class="btn btn-primary rounded-pill py-2 px-4" href="<?php echo e(url('service-details/'.$servicesList->slug), false); ?>">Read More</a>
                             </div>
                         </div>
                     </div>
                 </div>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       
      

           
         
                 
                 <div class="col-12 text-center wow fadeInUp" data-wow-delay="0.2s">
                     <a class="btn btn-primary rounded-pill py-3 px-5" href="<?php echo e(route('services'), false); ?>">More Services</a>
                 </div>
             </div>
         </div>
     </div>
     <!-- Service End -->


     <!-- Testimonial Start -->
     <div class="container-fluid testimonial pb-5">
         <div class="container pb-5">
             <div class="text-center mx-auto pb-5 wow fadeInUp" data-wow-delay="0.2s" style="max-width: 800px;">
                 <h4 class="text-primary">Testimonial</h4>
                 <h1 class="display-4 mb-4">What Our Customers Are Saying</h1>
                 <p class="mb-0">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Tenetur adipisci facilis cupiditate recusandae aperiam temporibus corporis itaque quis facere, numquam, ad culpa deserunt sint dolorem autem obcaecati, ipsam mollitia hic.
                 </p>
             </div>
             <div class="owl-carousel testimonial-carousel wow fadeInUp" data-wow-delay="0.2s">
                 <div class="testimonial-item bg-light rounded">
                     <div class="row g-0">
                         <div class="col-4  col-lg-4 col-xl-3">
                             <div class="h-100">
                                 <img src="img/testimonial-1.jpg" class="img-fluid h-100 rounded" style="object-fit: cover;" alt="">
                             </div>
                         </div>
                         <div class="col-8 col-lg-8 col-xl-9">
                             <div class="d-flex flex-column my-auto text-start p-4">
                                 <h4 class="text-dark mb-0">Client Name</h4>
                                 <p class="mb-3">Profession</p>
                                 <div class="d-flex text-primary mb-3">
                                     <i class="fas fa-star"></i>
                                     <i class="fas fa-star"></i>
                                     <i class="fas fa-star"></i>
                                     <i class="fas fa-star"></i>
                                     <i class="fas fa-star"></i>
                                 </div>
                                 <p class="mb-0">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Enim error molestiae aut modi corrupti fugit eaque rem nulla incidunt temporibus quisquam,
                                 </p>
                             </div>
                         </div>
                     </div>
                 </div>
                 <div class="testimonial-item bg-light rounded">
                     <div class="row g-0">
                         <div class="col-4  col-lg-4 col-xl-3">
                             <div class="h-100">
                                 <img src="img/testimonial-2.jpg" class="img-fluid h-100 rounded" style="object-fit: cover;" alt="">
                             </div>
                         </div>
                         <div class="col-8 col-lg-8 col-xl-9">
                             <div class="d-flex flex-column my-auto text-start p-4">
                                 <h4 class="text-dark mb-0">Client Name</h4>
                                 <p class="mb-3">Profession</p>
                                 <div class="d-flex text-primary mb-3">
                                     <i class="fas fa-star"></i>
                                     <i class="fas fa-star"></i>
                                     <i class="fas fa-star"></i>
                                     <i class="fas fa-star"></i>
                                     <i class="fas fa-star text-body"></i>
                                 </div>
                                 <p class="mb-0">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Enim error molestiae aut modi corrupti fugit eaque rem nulla incidunt temporibus quisquam,
                                 </p>
                             </div>
                         </div>
                     </div>
                 </div>
                 <div class="testimonial-item bg-light rounded">
                     <div class="row g-0">
                         <div class="col-4  col-lg-4 col-xl-3">
                             <div class="h-100">
                                 <img src="img/testimonial-3.jpg" class="img-fluid h-100 rounded" style="object-fit: cover;" alt="">
                             </div>
                         </div>
                         <div class="col-8 col-lg-8 col-xl-9">
                             <div class="d-flex flex-column my-auto text-start p-4">
                                 <h4 class="text-dark mb-0">Client Name</h4>
                                 <p class="mb-3">Profession</p>
                                 <div class="d-flex text-primary mb-3">
                                     <i class="fas fa-star"></i>
                                     <i class="fas fa-star"></i>
                                     <i class="fas fa-star"></i>
                                     <i class="fas fa-star text-body"></i>
                                     <i class="fas fa-star text-body"></i>
                                 </div>
                                 <p class="mb-0">Lorem, ipsum dolor sit amet consectetur adipisicing elit. Enim error molestiae aut modi corrupti fugit eaque rem nulla incidunt temporibus quisquam,
                                 </p>
                             </div>
                         </div>
                     </div>
                 </div>
             </div>
         </div>
     </div>
     <!-- Testimonial End -->



<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Chetan Singh_ICE-1411_Web Technologies\resources\views/services.blade.php ENDPATH**/ ?>