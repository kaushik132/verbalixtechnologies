
<?php $__env->startSection('main-containers'); ?>



<div class="banner-sec inner-banner">
    <img src="<?php echo e(url('new/images/inner-banner.jpg'), false); ?>" alt="" class="banner-img">
    <div class="banner-text">
       <div class="container">
          <div class="row align-items-center">
             <div class="col-md-10 mx-auto text-center">
                <h2>We love hearing about <br> new projects</h2>
             </div>
             <div class="down_arrow inner_down show_arrow">
                <a href="#basic_contact">
                   <svg class="circle" xmlns="http://www.w3.org/2000/svg">
                      <g>
                         <ellipse class="background" ry="40" rx="40" cy="62.5" cx="62.5" stroke-width="1"/>
                         <ellipse class="foreground" ry="40" rx="40" cy="62.5" cx="62.5" stroke-width="1"/>
                      </g>
                   </svg>
                </a>
             </div>
          </div>
       </div>
    </div>
    <img src="<?php echo e(url('new/images/arrow-shape.png'), false); ?>" alt="" class="arrow-shape">
    <img src="<?php echo e(url('new/images/triangle-shape.png'), false); ?>" alt="" class="triangle-shape">
 </div>

 <section class="basic_section contact_inner" id="basic_contact">
    <div class="container">
       <h3 class="text-center">Please don't hesitate to tell us about yours.</h3>
       <div class="contact_form_box">
    <div align="center" style="padding-top: 30px;">
      <?php if(session()->has('message')): ?>
      <div class="alert alert-success">
         <button type="button" class="close" data-dismiss="alert">x</button>
         
         <?php echo e(session()->get('message'), false); ?>

      </div>
          
      <?php endif; ?>
    </div>
          <form action="<?php echo e(route('contactPost'), false); ?>" method="POST">
            <?php echo csrf_field(); ?>
             <div class="row mrg-0">
                <div class="col-md-12 pd-5">
                   <input type="text" name="name" placeholder="Name" class="form-control" oninput="this.value = this.value.replace(/[^A-Za-z+.]/g, '').replace(/(\..*?)\..*/g, '$1');"  value="<?php echo e(old('name'), false); ?>">
                   <span class="text-danger">
                     <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <?php echo e($message, false); ?>

                     <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                   </span>
                </div>
                <div class="col-md-6 pd-5">
                   <input type="email" name="email" placeholder="Email" class="form-control"  value="<?php echo e(old('email'), false); ?>">
                   <span class="text-danger">
                     <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <?php echo e($message, false); ?>

                     <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                   </span>
                </div>
                <div class="col-md-6 pd-5">
                   <input type="text" name="phone" placeholder="Phone" class="form-control" maxlength="10" oninput="this.value = this.value.replace(/[^0-9+.]/g, '').replace(/(\..*?)\..*/g, '$1');"  value="<?php echo e(old('phone'), false); ?>">
                   <span class="text-danger">
                     <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <?php echo e($message, false); ?>

                     <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                   </span>
                </div>
                <div class="col-md-6 pd-5">
                   <input type="text" name="company" placeholder="Company" class="form-control" value="<?php echo e(old('company'), false); ?>">
                   <span class="text-danger">
                     <?php $__errorArgs = ['company'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <?php echo e($message, false); ?>

                     <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                   </span>
                </div>
                <div class="col-md-6 pd-5">
                   <input type="text" name="company_website" placeholder="Company website" class="form-control"  value="<?php echo e(old('company_website'), false); ?>">
                   <span class="text-danger">
                     <?php $__errorArgs = ['company_website'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <?php echo e($message, false); ?>

                     <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                   </span>
                </div>

               <div class="col-md-6 pd-5">
                   <select name="subject" id="help" required="" class="form-control" >
                      <option>How can we help?</option >
                      <option value="Branding">Branding</option>
                      <option value="ERP or CRM">ERP or CRM</option>
                      <option value="Web Design / build">Web Design / build</option>
                      <option value="Mobile App Development">Mobile App Development</option>
                      <option value="Online Marketing [SEO, SMO]">Online Marketing [SEO, SMO]</option>
                      <option value="Others">Others</option>
                 </select>
                 <span class="text-danger">
                  <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                     <?php echo e($message, false); ?>

                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </span>
               </div>

                <div class="col-md-6 pd-5">
                   <select name="budget" id="budget" required="" class="form-control">
                      <option>What's your ideal budget?</option>
                      <option value="Less than ₹15,000">Less than ₹15,000</option>
                      <option value="₹15,000 - ₹30,000">₹15,000 - ₹30,000</option>
                      <option value="₹30,000 - ₹50,000">₹30,000 - ₹50,000</option>
                      <option value="₹50,000 - ₹100,000">₹50,000 - ₹100,000</option>
                      <option value="₹100,000 - ₹250,000">₹100,000 - ₹250,000</option>
                      <option value="₹250,000+">₹250,000+</option>
                   </select>
                   <span class="text-danger">
                     <?php $__errorArgs = ['budget'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <?php echo e($message, false); ?>

                     <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                   </span>
                </div>
                <div class="col-md-12 pd-5">
                   <textarea name="message"  class="form-control" placeholder="Anything else?"></textarea>
                   <span class="text-danger">
                     <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <?php echo e($message, false); ?>

                     <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                   </span>
                </div>
                <div class="col-md-12 pd-5">
                   <div class="custome_checkbox">
                      <input type="checkbox"  id="check">  <label for="check">I agree to the AdSquad <a href="javascript: ;">Privacy Policy</a></label>
                   </div>
                </div>
                <div class="col-md-12 pd-5 text-md-right">
                   <input type="submit" id="submitBtn" disabled  value="Submit" class="submit_btn">
                </div>
             </div>
          </form>
       </div>
    </div>
 </section>

 <script>
   document.getElementById("check").addEventListener("change", function() {
       var submitBtn = document.getElementById("submitBtn");
       submitBtn.disabled = !this.checked;
   });
</script>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Codepin_new\resources\views/contact.blade.php ENDPATH**/ ?>