<?php
    echo '<?xml version="1.0" encoding="UTF-8"?>'
?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">

    <url>
        <loc>https://codepin.org/</loc>
        <lastmod>2024-05-02T07:54:52+00:00</lastmod>
        <changefreq>Weekly</changefreq>
        <priority>0.8</priority>
    </url>


    <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blogs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
    <url>
        <loc><?php echo e(url('/'), false); ?>/blogs/<?php echo e($blogs->slug, false); ?></loc>
        <lastmod><?php echo e($blogs->created_at->tz('UTC')->toAtomString(), false); ?></lastmod>
        <changefreq>Weekly</changefreq>
        <priority>0.8</priority>
    </url>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $services): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
    <url>
        <loc><?php echo e(url('/'), false); ?>/services/<?php echo e($services->slug, false); ?></loc>
        <lastmod><?php echo e($services->created_at->tz('UTC')->toAtomString(), false); ?></lastmod>
        <changefreq>Weekly</changefreq>
        <priority>0.8</priority>
    </url>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




</urlset><?php /**PATH D:\xampp\htdocs\Codepin_new\resources\views/sitemap.blade.php ENDPATH**/ ?>