
<?php $__env->startSection('main-containers'); ?>
    <div class="banner-sec inner-banner">
        <img src="<?php echo e(url('new/images/inner-banner.jpg'), false); ?>" alt="" class="banner-img">
        <div class="banner-text">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <h2><?php echo e($servicesData->serviceCategory->name, false); ?></h2>
                    </div>
                    <div class="col-md-4 text-md-end">
                        <img src="<?php echo e(url('new/images/inner-banner.jpg'), false); ?>" alt="" class="main-img">
                    </div>
                </div>
            </div>
        </div>
        <img src="<?php echo e(url('new/images/arrow-shape.png'), false); ?>" alt="" class="arrow-shape">
        <img src="<?php echo e(url('new/images/triangle-shape.png'), false); ?>" alt="" class="triangle-shape">
    </div>

    <section class="section main-services">
        <img src="<?php echo e(url('new/images/dotted-square.png'), false); ?>" alt="" class="dotsquare">
        <div class="container">
            <div class="row row-flex">
                <div class="col-md-4 col-xs-12 sidebar">
                    <div class="service-box">
                        <ul>
                            <?php $__currentLoopData = $servicelist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li class="active">
                                    <a href="<?php echo e(route('servicesDetails',$item->slug), false); ?>">
                                        <figure>
                                            <img src="<?php echo e(asset('uploads/'.$item->home_image), false); ?>" alt="">
                                        </figure>
                                        <?php echo e($item->serviceCategory->name, false); ?>

                                    </a>
                                </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                        </ul>
                    </div>
                    <div class="rg-block">
                        <img src="<?php echo e(url('new/images/contact-bnr.jpg'), false); ?>" alt="" class="radius20">
                        <div class="rg-text">
                            <h3>We Answer Your Queries!</h3>
                            <p>Want To Hire The Best Talent?</p>
                            <a href="<?php echo e(route('contact'), false); ?>" class="btn-outline line-animation">Enquire now</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-8">
                    <div class="cp-about">
                        <h3><?php echo e($servicesData->short_content, false); ?></h3>
                        <p><?php echo $servicesData->description; ?></p>
                  

                       
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="tech-logo dark-light">
        <div class="container">
            <div class="row ">
                <div class="col-lg-12">
                    <div class="inner_title text-center title_btm">
                        <h1>Technologies We Use</h1>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-3 col-lg-1 col-md-2 col-sm-3">
                    <div class="tech-cp">
                        <img src="<?php echo e(url('new/images/figma.svg'), false); ?>" alt="">
                    </div>
                </div>
                <div class="col-3 col-lg-1 col-md-2 col-sm-3">
                    <div class="tech-cp">
                        <img src="<?php echo e(url('new/images/ps.svg'), false); ?>" alt="">
                    </div>
                </div>
                <div class="col-3 col-lg-1 col-md-2 col-sm-3">
                    <div class="tech-cp">
                        <img src="<?php echo e(url('new/images/sass.svg'), false); ?>" alt="">
                    </div>
                </div>
                <div class="col-3 col-lg-1 col-md-2 col-sm-3">
                    <div class="tech-cp">
                        <img src="<?php echo e(url('new/images/react.svg'), false); ?>" alt="">
                    </div>
                </div>
                <div class="col-3 col-lg-1 col-md-2 col-sm-3">
                    <div class="tech-cp">
                        <img src="<?php echo e(url('new/images/js.svg'), false); ?>" alt="">
                    </div>
                </div>
                <div class="col-3 col-lg-1 col-md-2 col-sm-3">
                    <div class="tech-cp">
                        <img src="<?php echo e(url('new/images/laravel.svg'), false); ?>" alt="">
                    </div>
                </div>
                <div class="col-3 col-lg-1 col-md-2 col-sm-3">
                    <div class="tech-cp">
                        <img src="<?php echo e(url('new/images/node.svg'), false); ?>" alt="">
                    </div>
                </div>
                <div class="col-3 col-lg-1 col-md-2 col-sm-3">
                    <div class="tech-cp">
                        <img src="<?php echo e(url('new/images/wordpress.svg'), false); ?>" alt="">
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="about-sec choose-sec">
        <div class="container reason-sec text-center">
            <div class="row">
                <div class="col-lg-10 mx-auto title">
                    <h2 class="lg-title">Why Choose <span class="primary-text">CodePin</span> for Your Digital
                        Transformation?</h2>
                    <p>At CodePin, we understand the challenges of navigating the ever-evolving digital landscape. That's
                        why we offer a comprehensive suite of services designed to empower your business and achieve your
                        online goals. Here's what sets us apart:</p>
                </div>
            </div>
        </div>
        <div class="container cp-about">
            <div class="col-12 dark-light">
                <div class="row align-items-center">
                    <div class="col-md-4 pr-md-4 mb-md-0 mb-4">
                        <img src="<?php echo e(url('new/images/why-img1.jpg'), false); ?>" alt="images" class="thumb_img ">
                    </div>
                    <div class="col-md-8">
                        <h3><strong>Full-Service Digital Agency</strong></h3>
                        <p>Tired of juggling multiple vendors for your digital needs? CodePin provides a one-stop shop for
                            all your requirements, including <strong>digital marketing, UI/UX design, e-commerce solutions,
                                website development, app development, and custom software development</strong>. This saves
                            you time, simplifies project management, and ensures seamless integration across different
                            aspects of your digital strategy.</p>
                    </div>
                </div>
            </div>
            <div class="col-12 dark-light">
                <div class="row align-items-center">
                    <div class="col-md-4 pr-md-4 mb-md-0 mb-4">
                        <img src="<?php echo e(url('new/images/why-img2.jpg'), false); ?>" alt="images" class="thumb_img ">
                    </div>
                    <div class="col-md-8">
                        <h3><strong>User-Centric Design & Development</strong></h3>
                        <p>We understand that user experience (UX) is paramount to success. Our skilled designers and
                            developers focus on creating <strong>intuitive, user-friendly websites, apps, and marketing
                                campaigns</strong> that resonate with your target audience, driving engagement and
                            conversions.</p>
                    </div>
                </div>
            </div>
            <div class="col-12 dark-light">
                <div class="row align-items-center">
                    <div class="col-md-4 pr-md-4 mb-md-0 mb-4">
                        <img src="<?php echo e(url('new/images/why-img3.jpg'), false); ?>" alt="images" class="thumb_img ">
                    </div>
                    <div class="col-md-8">
                        <h3><strong>Expertise at Your Fingertips</strong></h3>
                        <p>Our team of <strong>experienced and passionate professionals</strong> brings together a wealth of
                            knowledge and expertise in various digital disciplines. We don't just create solutions, we
                            <strong>deliver results</strong> that contribute to your overall business growth.</p>

                        <p>This saves you time, simplifies project management, and ensures seamless integration across
                            different aspects of your digital strategy.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="work-process wh-bg">
        <div class="container">
            <div class="row ">
                <div class="col-lg-12">
                    <div class="inner_title text-center title_btm">
                        <h1>Our process to work for you and it goes a little something like this:</h1>
                    </div>
                    <div class="work-process-img">
                        <img src="<?php echo e(url('new/images/work-process.svg'), false); ?>" alt="">
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="cp-about pt-0">

        <div class="container contact-bd-sec line-pattern text-center">
            <div class="row">
                <div class="col-lg-9 mx-auto">
                    <img src="<?php echo e(url('new/images/happy.png'), false); ?>" alt="">
                    <h2 class="lg-title">Ready to take your business to the next level?</h2>
                    <h4 class="mb-4">Contact <span class="primary-text">CodePin</span> today for a free consultation!
                    </h4>
                    <a href="<?php echo e(route('contact'), false); ?>" class="btn-outline line-animation">Contact Us</a>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Codepin_new\resources\views/service-details.blade.php ENDPATH**/ ?>