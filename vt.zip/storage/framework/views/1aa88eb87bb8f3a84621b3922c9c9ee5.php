
<?php $__env->startSection('main-containers'); ?>


<h1>Home Page</h1>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Codepin_new\resources\views/index.blade.php ENDPATH**/ ?>