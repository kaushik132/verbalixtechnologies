<?php $__env->startSection('main-containers'); ?>

  

<!-- Header Start -->

<div class="container-fluid bg-breadcrumb"  style="background-image: url(../uploads/<?php echo e($servicesData->home_image, false); ?>)">

    <div class="container text-md-start text-center py-5" style="max-width: 900px;">

        <h4 class="text-white display-4 mb-4 wow fadeInDown" data-wow-delay="0.1s">Service Details</h4>

        <ol class="breadcrumb d-flex mb-0 wow fadeInDown" data-wow-delay="0.3s">

            <li class="breadcrumb-item"><a href="<?php echo e(route('index'), false); ?>">Home</a></li>

            <li class="breadcrumb-item"><a href="#">Service</a></li>

            <li class="breadcrumb-item active text-white">Service-details</li>

        </ol>    

    </div>

</div>

<!-- Header End -->



<!-- ------------------Service start--------------- -->

<div class="container-fluid testimonial pb-5 mt-5">

    <div class="container pb-5">

        <div class="row g-4 justify-content-center">

        <div class="col-lg-8 col-xl-8 wow fadeInUp" data-wow-delay="0.2s">

      <?php echo $servicesData->description; ?>


</div>

<div class="col-lg-4 col-xl-4 wow fadeInUp" data-wow-delay="0.4s">

  <h3>More Services</h3>

  <div class="cate-blog-border mt-3">

  

  <?php $__currentLoopData = $servicedetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servicedetails): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

      

  <a href="<?php echo e(url('services/'.$servicedetails->slug), false); ?>"><div class="mt-3 d-flex justify-content-between">

     <h6><?php echo e($servicedetails->name, false); ?></h6>

     <h6><?php echo e($servicedetails->services_count, false); ?></h6>

   </div>

  </a>

  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>





   </div>

   <?php if(session()->has('message')): ?>

   <div class="alert alert-success">

      

      

      <?php echo e(session()->get('message'), false); ?>


   </div>

       

   <?php endif; ?>





    <div class="service-form-box">

        <h4 class="text-primary">Send Your Message</h4>

        <p class="mb-4">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Totam, accusamus.</p>

        <form action="<?php echo e(route('contactPost'), false); ?>" method="POST">

            <?php echo csrf_field(); ?>

            <div class="row g-3">

                <div class="col-lg-12 col-xl-6">

                    <div class="form-floating">

                        <input type="text" name="name" class="form-control border-0" id="name" placeholder="Your Name" oninput="this.value = this.value.replace(/[^A-Za-z+.]/g, '').replace(/(\..*?)\..*/g, '$1');"  value="<?php echo e(old('name'), false); ?>">

                        <label for="name">Your Name</label>

                        <span class="text-danger">

                            <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                               <?php echo e($message, false); ?>


                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                          </span>

                    </div>

                </div>

                <div class="col-lg-12 col-xl-6">

                    <div class="form-floating">

                        <input type="email" name="email"  class="form-control border-0" id="email" value="<?php echo e(old('email'), false); ?>" placeholder="Your Email">

                        <label for="email">Your Email</label>

                        <span class="text-danger">

                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                               <?php echo e($message, false); ?>


                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                          </span>

                    </div>

                </div>

                <div class="col-lg-12 col-xl-6">

                    <div class="form-floating">

                        <input type="phone" name="phone" class="form-control border-0" id="phone" placeholder="Phone" maxlength="10" oninput="this.value = this.value.replace(/[^0-9+.]/g, '').replace(/(\..*?)\..*/g, '$1');"  value="<?php echo e(old('phone'), false); ?>">

                        <label for="phone">Your Phone</label>

                        <span class="text-danger">

                            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                               <?php echo e($message, false); ?>


                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                          </span>

                    </div>

                </div>

                <div class="col-lg-12 col-xl-6">

                    <div class="form-floating">

                        <input type="text" name="project" class="form-control border-0" id="project" value="<?php echo e(old('project'), false); ?>" placeholder="Project">

                        <label for="project">Your Project</label>

                        <span class="text-danger">

                            <?php $__errorArgs = ['project'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                               <?php echo e($message, false); ?>


                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                          </span>

                    </div>

                </div>

                <div class="col-12">

                    <div class="form-floating">

                        <input type="text" name="subject" class="form-control border-0" id="subject" value="<?php echo e(old('subject'), false); ?>" placeholder="Subject">

                        <label for="subject">Subject</label>

                        <span class="text-danger">

                            <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                               <?php echo e($message, false); ?>


                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                          </span>

                    </div>

                </div>

                <div class="col-12">

                    <div class="form-floating">

                        <textarea name="message" class="form-control border-0" placeholder="Leave a message here" id="message" style="height: 120px"></textarea>

                        <label for="message">Message</label>

                        <span class="text-danger">

                            <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>

                               <?php echo e($message, false); ?>


                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                          </span>

                    </div>



                </div>

                <div class="col-12">

                    <button type="submit" class="btn btn-primary w-100 py-3">Send Message</button>

                </div>

            </div>

        </form>

    </div>


</div>

</div>



</div>

        </div>

<!-- -----------------Service End---------------------- -->



<div class="container-fluid service py-5">

    <div class="container py-5">

        <div class="text-center mx-auto pb-5 wow fadeInUp" data-wow-delay="0.2s" style="max-width: 800px;">

            <h3 class="text-primary">More Services</h3>

        </div>

        <div class="row g-4 justify-content-center">

         <?php $__currentLoopData = $servicelist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servicelist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

             

         

            <div class="col-md-6 col-lg-6 col-xl-3 wow fadeInUp" data-wow-delay="0.4s">

                <div class="service-item">

                    <div class="service-img">

                        <img src="<?php echo e(url('uploads/' . $servicelist->image), false); ?>" class="img-fluid rounded-top w-100" alt="">

                        <div class="service-icon p-3">

                            <i class="fa fa-database fa-2x"></i>

                        </div>

                    </div>

                    <div class="service-content p-4">

                        <div class="service-content-inner">

                            <a href="<?php echo e(url('service-details/'.$servicelist->slug), false); ?>" class="d-inline-block h4 mb-4"><?php echo e($servicelist->title, false); ?></a>

                            <p class="mb-4"><?php echo e($servicelist->short_content, false); ?></p>

                            <a class="btn btn-primary rounded-pill py-2 px-4" href="<?php echo e(url('service-details/'.$servicelist->slug), false); ?>">Read More</a>

                        </div>

                    </div>

                </div>

            </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        

      



            <div class="col-12 text-center wow fadeInUp" data-wow-delay="0.2s">

                <a class="btn btn-primary rounded-pill py-3 px-5" href="<?php echo e(route('services'), false); ?>">More Services</a>

            </div>

        </div>

    </div>

</div>





        <!-- Testimonial Start -->

        <div class="container-fluid testimonial pb-5">

            <div class="container pb-5">

                <div class="text-center mx-auto pb-5 wow fadeInUp" data-wow-delay="0.2s" style="max-width: 800px;">

                    <h4 class="text-primary">Testimonial</h4>

                    <h1 class="display-4 mb-4">What Our Customers Are Saying</h1>

                    <p class="mb-0">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Tenetur adipisci facilis cupiditate recusandae aperiam temporibus corporis itaque quis facere, numquam, ad culpa deserunt sint dolorem autem obcaecati, ipsam mollitia hic.

                    </p>

                </div>

                <div class="owl-carousel testimonial-carousel wow fadeInUp" data-wow-delay="0.2s">

                    <?php $__currentLoopData = $testimonial; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        

                

                    <div class="testimonial-item bg-light rounded">

                        <div class="row g-0">

                            <div class="col-4  col-lg-4 col-xl-3">

                                <div class="h-100">

                                    <img src="<?php echo e(url('uploads/'.$testimonial->image), false); ?>" class="img-fluid h-100 rounded" style="object-fit: cover;" alt="<?php echo e($testimonial->alt, false); ?>">

                                </div>

                            </div>

                            <div class="col-8 col-lg-8 col-xl-9">

                                <div class="d-flex flex-column my-auto text-start p-4">

                                    <h4 class="text-dark mb-0"><?php echo e($testimonial->name, false); ?></h4>

                                    <p class="mb-3"><?php echo e($testimonial->profaction, false); ?></p>

                                    <div class="d-flex text-primary mb-3">

                                        <?php for($i = 1; $i <= 5; $i++): ?>

                                            <?php if($i <= $testimonial->rating): ?>

                                                <i class="fas fa-star"></i>

                                            <?php else: ?>

                                                <i class="fas fa-star text-body"></i>

                                            <?php endif; ?>

                                        <?php endfor; ?>

                                    </div>

                                    

                                    <p class="mb-0"><?php echo e($testimonial->description, false); ?>


                                    </p>

                                </div>

                            </div>

                        </div>

                    </div>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

             

                </div>

            </div>

        </div>

        <!-- Testimonial End -->







<?php $__env->stopSection(); ?>


<?php echo $__env->make('dashboard.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/codepino/verbalixtechnologies.com/resources/views/service-details.blade.php ENDPATH**/ ?>