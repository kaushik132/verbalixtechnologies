<footer class="navbar navbar-light bg-white py-3 px-4 <?php if(!empty($fixedFooter)): ?>shadow fixed-bottom <?php endif; ?>">
    <div class="flex-grow-1"><?php echo $range; ?></div>
    <div class="pe-2"><?php echo $per_page; ?></div>
    <div><?php echo $links; ?></div>
</footer>
<?php /**PATH D:\xampp\htdocs\Chetan Singh_ICE-1411_Web Technologies\vendor\open-admin-org\open-admin\src/../resources/views/grid/pagination.blade.php ENDPATH**/ ?>