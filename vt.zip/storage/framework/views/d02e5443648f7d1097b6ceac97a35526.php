
<?php $__env->startSection('main-containers'); ?>



  <!-- Header Start -->
  <div class="container-fluid bg-breadcrumb" style="background-image: url(../uploads/<?php echo e($banner['banner'], false); ?>)">
   <div class="container text-md-start text-center py-5" style="max-width: 900px;">
       <h4 class="text-white display-4 mb-4 wow fadeInDown" data-wow-delay="0.1s">Contact Us</h4>
       <ol class="breadcrumb d-flex mb-0 wow fadeInDown" data-wow-delay="0.3s">
           <li class="breadcrumb-item"><a href="index.html">Home</a></li>
           <li class="breadcrumb-item"><a href="#">Pages</a></li>
           <li class="breadcrumb-item active text-white">Contact</li>
       </ol>    
   </div>
</div>
<!-- Header End -->


<!-- Contact Start -->
<div class="container-fluid contact bg-light py-5">
   <div class="container py-5">
       <div class="text-center mx-auto pb-5 wow fadeInUp" data-wow-delay="0.2s" style="max-width: 800px;">
           <h4 class="text-primary">Contact Us</h4>
           <h1 class="display-4 mb-4">If you have any comments please apply now</h1>
       </div>
       <div class="row g-5">
           <div class="col-xl-6 wow fadeInLeft" data-wow-delay="0.2s">
               <div class="contact-img d-flex justify-content-center" >
                   <div class="contact-img-inner">
                       <img src="<?php echo e(url('web/img/contact-img.png'), false); ?>" class="img-fluid w-100"  alt="Image">
                   </div>
               </div>
           </div>
           <div class="col-xl-6 wow fadeInRight" data-wow-delay="0.4s">
               <div>
                   <h4 class="text-primary">Send Your Message</h4>
                   <p class="mb-4">Lorem ipsum dolor sit, amet consectetur adipisicing elit. Totam, accusamus.</p>

                   <?php if(session()->has('message')): ?>
                   <div class="alert alert-success">
                      
                      
                      <?php echo e(session()->get('message'), false); ?>

                   </div>
                       
                   <?php endif; ?>
             

                   <form action="<?php echo e(route('contactPost'), false); ?>" method="POST">
                     <?php echo csrf_field(); ?>
                       <div class="row g-3">
                           <div class="col-lg-12 col-xl-6">
                               <div class="form-floating">
                                   <input type="text" name="name" class="form-control border-0" id="name" oninput="this.value = this.value.replace(/[^A-Za-z+.]/g, '').replace(/(\..*?)\..*/g, '$1');"  value="<?php echo e(old('name'), false); ?>" placeholder="Your Name">
                                   <label for="name">Your Name</label>
                                   <span class="text-danger">
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                       <?php echo e($message, false); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                  </span>
               
                               </div>
                           </div>
                           <div class="col-lg-12 col-xl-6">
                               <div class="form-floating">
                                   <input type="email" name="email" class="form-control border-0" id="email" placeholder="Your Email" value="<?php echo e(old('email'), false); ?>">
                                   <label for="email">Your Email</label>
                                   <span class="text-danger">
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                       <?php echo e($message, false); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                  </span>
               
                               </div>
                           </div>
                           <div class="col-lg-12 col-xl-6">
                               <div class="form-floating">
                                   <input type="phone" name="phone" class="form-control border-0" id="phone"  maxlength="10" oninput="this.value = this.value.replace(/[^0-9+.]/g, '').replace(/(\..*?)\..*/g, '$1');"  value="<?php echo e(old('phone'), false); ?>" placeholder="Phone">
                                   <label for="phone">Your Phone</label>
                                   <span class="text-danger">
                                    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                       <?php echo e($message, false); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                  </span>
               
                               </div>
                           </div>
                           <div class="col-lg-12 col-xl-6">
                               <div class="form-floating">
                                   <input type="text" name="project" class="form-control border-0" id="project" value="<?php echo e(old('project'), false); ?>" placeholder="Project">
                                   <label for="project">Your Project</label>
                                   <span class="text-danger">
                                    <?php $__errorArgs = ['project'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                       <?php echo e($message, false); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                  </span>
               
                               </div>
                           </div>
                           <div class="col-12">
                               <div class="form-floating">
                                   <input type="text" name="subject" class="form-control border-0" id="subject" value="<?php echo e(old('subject'), false); ?>" placeholder="Subject">
                                   <label for="subject">Subject</label>
                                   <span class="text-danger">
                                    <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                       <?php echo e($message, false); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                  </span>
               
                               </div>
                           </div>
                           <div class="col-12">
                               <div class="form-floating">
                                   <textarea class="form-control border-0" name="message" placeholder="Leave a message here" id="message" style="height: 120px"></textarea>
                                   <label for="message">Message</label>
                                   <span class="text-danger">
                                    <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                       <?php echo e($message, false); ?>

                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                  </span>
               
                               </div>

                           </div>
                           <div class="col-12">
                               <button type="submit" class="btn btn-primary w-100 py-3">Send Message</button>
                           </div>
                       </div>
                   </form>


               </div>
           </div>
           <div class="col-12">
               <div>
                   <div class="row g-2">
                       <div class="col-md-6 col-lg-4 wow fadeInUp text-center" data-wow-delay="0.2s">
                           <div class="contact-add-item">
                               <div class="contact-icon text-primary mb-4">
                                   <i class="fas fa-map-marker-alt fa-2x"></i>
                               </div>
                               <div>
                                   <h4>Address</h4>
                                   <p class="mb-0"><?php echo e($homeData->address ?? '', false); ?></p>
                               </div>
                           </div>
                       </div>
                       <div class="col-md-6 col-lg-4 wow fadeInUp text-center" data-wow-delay="0.4s">
                           <div class="contact-add-item">
                               <div class="contact-icon text-primary mb-4">
                                   <i class="fas fa-envelope fa-2x"></i>
                               </div>
                               <div>
                                   <h4>Mail Us</h4>
                                   <p class="mb-0"><?php echo e($homeData->email ?? 'example@gmail.com', false); ?></p>
                               </div>
                           </div>
                       </div>
                       <div class="col-md-6 col-lg-4 wow fadeInUp text-center" data-wow-delay="0.6s">
                           <div class="contact-add-item">
                               <div class="contact-icon text-primary mb-4">
                                   <i class="fa fa-phone-alt fa-2x"></i>
                               </div>
                               <div>
                                   <h4>Telephone</h4>
                                   <p class="mb-0"><?php echo e($homeData->phone_no ?? '', false); ?></p>
                               </div>
                           </div>
                       </div>
                  
                   </div>
               </div>
           </div>
           <div class="col-12 wow fadeInUp" data-wow-delay="0.2s">
               <div class="rounded">
                   <iframe class="rounded w-100" 
                   style="height: 400px;" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d387191.33750346623!2d-73.97968099999999!3d40.6974881!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c24fa5d33f083b%3A0xc80b8f06e177fe62!2sNew%20York%2C%20NY%2C%20USA!5e0!3m2!1sen!2sbd!4v1694259649153!5m2!1sen!2sbd" 
                   loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
               </div>
           </div>
       </div>
   </div>
</div>
<!-- Contact End -->







<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Chetan Singh_ICE-1411_Web Technologies\resources\views/contact.blade.php ENDPATH**/ ?>