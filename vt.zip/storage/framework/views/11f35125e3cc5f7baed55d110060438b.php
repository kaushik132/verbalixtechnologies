
<?php $__env->startSection('main-containers'); ?>


<div class="banner-sec inner-banner">
    <img src="<?php echo e(url('new/images/inner-banner.jpg'), false); ?>" alt="" class="banner-img">
    <div class="banner-text">
       <div class="container">
          <div class="row align-items-center">
             <div class="col-md-8">
                <h2>Our Services</h2>
             </div>
             <div class="col-md-4 text-md-end">
                <img src="<?php echo e(url('new/images/services-inner.png'), false); ?>" alt="" class="main-img">
             </div>
          </div>
       </div>
    </div>
    <img src="<?php echo e(url('new/images/arrow-shape.png'), false); ?>" alt="" class="arrow-shape">
    <img src="<?php echo e(url('new/images/triangle-shape.png'), false); ?>" alt="" class="triangle-shape">
 </div>
 <section class="cp-about solution">
    <div class="container">
       <div class="row">
          <div class="col-md-6">
             <div class="row">
                <div class="col-7">
                   <figure>
                      <img src="<?php echo e(url('new/images/srv-dtls-img1.jpg'), false); ?>" alt="" class="radius20">
                   </figure>
                </div>
                <div class="col-5">
                <figure class="mb-md-4">
                   <img src="<?php echo e(url('new/images/srv-dtls-img2.jpg'), false); ?>" alt="" class="radius20">
                </figure>
                
                <figure>
                   <img src="<?php echo e(url('new/images/srv-dtls-img3.jpg'), false); ?>" alt="" class="radius20">
                </figure>
                
                </div>
             </div>
          </div>
          <div class="col-md-6 my-auto">
             <h2 class="lg-title">So, Why work with us?</h2>
             <!-- <h3>Data-Driven Strategies &amp; Expert Development for Maximum Impact</h3> -->
             <p><strong>CodePin</strong> is more than just a digital agency; we're your strategic growth partner. We're a passionate team of developers, marketers, and creative minds who work tirelessly to propel businesses like yours to unprecedented heights in the digital arena.</p>
             <p>We don't just take orders; we become <strong>active partners</strong> in your success story. We listen to your goals, understand your brand, and tailor our solutions to your unique needs.</p>
             <div class="arrow mt-5">
                <img src="<?php echo e(url('new/images/right-arrow.png'), false); ?>" alt="">
             </div>
          </div>
       </div>
       <div class="row mt-5">
          <div class="col-md-4">
             <div class="inner-box">
                <h3><span>1.</span> Modern<br> Solution</h3>
                <p>Modern challenges require modern digital solutions that blend creativity and strategy at the core.</p>
             </div>
          </div>
          <div class="col-md-4">
             <div class="inner-box">
                <h3><span>2.</span> Competitive<br> Pricing</h3>
                <p>No hidden charges, no gimmicky offers. We know how to work around different budgets.</p>
             </div>
          </div>
          <div class="col-md-4">
             <div class="inner-box">
                <h3><span>3.</span> Team that<br> cares</h3>
                <p>We're not a fan of the discover-deliver-forget model. We care about our clients’ long-term success.</p>
             </div>
          </div>
       </div>
    </div>
 </section>
 
 <section class="service-aection line-pattern">
    <div class="container ">
       <div class="col-12 text-center title">
          <h2 class="lg-title">Our Services</h2>
          <p>
             Maximize your digital exposure with our comprehensive package of products.
          </p>
       </div>
       <div class="service_list">
          <ul>

            <?php $__currentLoopData = $servicesList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
            <li>
               <div class="cp-box">
                  <figure>
                     <img src="<?php echo e(asset('uploads/'.$item->home_image), false); ?>" alt="">
                  </figure>
                  <h3><a href="<?php echo e(route('servicesDetails',$item->slug), false); ?>"><?php echo e($item->serviceCategory->name, false); ?></a></h3>
                  <!-- <h4>We have all marketing solutions</h4> -->
                  <a href="<?php echo e(route('servicesDetails',$item->slug), false); ?>" class="link-ui">
                     <img src="<?php echo e(url('new/images/link-arrow.png'), false); ?>" alt="">
                  </a>
               </div>
            </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
       
    
          
  
          </ul>
       </div>
    </div>
 </section>

 <section class="tech-logo">
    <div class="container">
       <div class="row ">
          <div class="col-lg-12">
             <div class="inner_title text-center title_btm">
                <h1>Technologies We Use</h1>
             </div>
          </div>
       </div>
       <div class="row justify-content-center">
          <div class="col-3 col-lg-1 col-md-2 col-sm-3">
             <div class="tech-cp">
                <img src="<?php echo e(url('new/images/figma.svg'), false); ?>" alt="">
             </div>
          </div>
          <div class="col-3 col-lg-1 col-md-2 col-sm-3">
             <div class="tech-cp">
                <img src="<?php echo e(url('new/images/ps.svg'), false); ?>" alt="">
             </div>
          </div>
          <div class="col-3 col-lg-1 col-md-2 col-sm-3">
             <div class="tech-cp">
                <img src="<?php echo e(url('new/images/sass.svg'), false); ?>" alt="">
             </div>
          </div>
          <div class="col-3 col-lg-1 col-md-2 col-sm-3">
             <div class="tech-cp">
                <img src="<?php echo e(url('new/images/react.svg'), false); ?>" alt="">
             </div>
          </div>
          <div class="col-3 col-lg-1 col-md-2 col-sm-3">
             <div class="tech-cp">
                <img src="<?php echo e(url('new/images/js.svg'), false); ?>" alt="">
             </div>
          </div>
          <div class="col-3 col-lg-1 col-md-2 col-sm-3">
             <div class="tech-cp">
                <img src="<?php echo e(url('new/images/laravel.svg'), false); ?>" alt="">
             </div>
          </div>
          <div class="col-3 col-lg-1 col-md-2 col-sm-3">
             <div class="tech-cp">
                <img src="<?php echo e(url('new/images/node.svg'), false); ?>" alt="">
             </div>
          </div>
          <div class="col-3 col-lg-1 col-md-2 col-sm-3">
             <div class="tech-cp">
                <img src="<?php echo e(url('new/images/wordpress.svg'), false); ?>" alt="">
             </div>
          </div>
       </div>
    </div>
 </section>
 <section class="work-process wh-bg">
    <div class="container">
       <div class="row ">
          <div class="col-lg-12">
             <div class="inner_title text-center title_btm">
                <h1>Our process to work for you and it goes a little something like this:</h1>
             </div>
             <div class="work-process-img">
                <img src="<?php echo e(url('new/images/work-process.svg'), false); ?>" alt="">
             </div>
          </div>
       </div>
    </div>
 </section>
 
 <section class="amigos_inner social-media-mr">
    <div class="container">
       <!-- <div class="side_img"> <img src="images/social-media.jpg" alt="images" class="img-fluid "></div> -->
       <div class="row">
          <div class="col-md-5">
             <img src="<?php echo e(url('new/images/social-media.jpg'), false); ?>" alt="images" class="img-fluid ">
          </div>
          <div class="col-md-7" >
             <div class="inner_title text-left">
                <h1>Brands</h1>
             </div>
             <p class="short_info" > From ambitious startups to industry
                leaders, we create brand experiences
                for clients all around the world.
             </h5>
             <div class="logos">
                <img src="<?php echo e(url('new/images/costa-img.svg'), false); ?>" alt="logo">
                <img src="<?php echo e(url('new/images/bbc.svg'), false); ?>" alt="logo">
                <img src="<?php echo e(url('new/images/itv.svg'), false); ?>" alt="logo">
                <img src="<?php echo e(url('new/images/deezer.svg'), false); ?>" alt="logo">
                <img src="<?php echo e(url('new/images/bmw.svg'), false); ?>" alt="logo">
                <img src="<?php echo e(url('new/images/jbcapital.svg'), false); ?>" alt="logo">
                <img src="<?php echo e(url('new/images/mediatree.svg'), false); ?>" alt="logo">
                <img src="<?php echo e(url('new/images/carrefour.svg'), false); ?>" alt="logo">
                <img src="<?php echo e(url('new/images/jlc.svg'), false); ?>" alt="logo">
             </div>
          </div>
       </div>
    </div>
 </section>







<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Codepin_new\resources\views/services.blade.php ENDPATH**/ ?>