<?php echo $__env->make("admin::form._header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <style>
            .cke_editor_column, .cke_editor_body{
                border-radius:0.25rem;
                overflow:hidden;
                border-color:#ced4da;
            }
            .cke_focus{
                border-color:#9dcbff;
                box-shadow:0 0 0 .25rem rgba(58,150,255,.25);
            }
        </style>
        <textarea name="<?php echo e($name, false); ?>" rows="<?php echo e($rows, false); ?>" id="<?php echo e($id, false); ?>" placeholder="<?php echo e($placeholder, false); ?>" <?php echo $attributes; ?> >
            <?php echo e(old($column, $value), false); ?>

        </textarea>

<?php echo $__env->make("admin::form._footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Codepin_new\vendor\open-admin-ext\ckeditor\src/../resources/views/editor.blade.php ENDPATH**/ ?>