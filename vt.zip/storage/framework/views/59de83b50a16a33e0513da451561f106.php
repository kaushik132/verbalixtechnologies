<?php $__env->startSection('main-containers'); ?>



<?php

    use Carbon\Carbon;





$date = Carbon::parse($blogData->created_at)->format('d M, Y');

?>





<!-- Header Start -->

<div class="container-fluid bg-breadcrumb" style="background-image: url(../uploads/<?php echo e($blogData->home_image, false); ?>)">

   <div class="container text-md-start text-center py-5" style="max-width: 900px;">

       <h4 class="text-white display-4 mb-4 wow fadeInDown" data-wow-delay="0.1s">Blog Details</h4>

       <ol class="breadcrumb d-flex mb-0 wow fadeInDown" data-wow-delay="0.3s">

           <li class="breadcrumb-item"><a href="<?php echo e(route('index'), false); ?>">Home</a></li>

           <li class="breadcrumb-item"><a href="#">Blog</a></li>

           <li class="breadcrumb-item active text-white">Blog-details</li>

       </ol>    

   </div>

</div>

<!-- Header End -->

<!-- ------------Blog Details Start---------------------- -->

<div class="container-fluid blog py-5">

   <div class="container py-5">

       <div class="row g-4 justify-content-center">

           <div class="col-lg-8 col-xl-8 wow fadeInUp" data-wow-delay="0.2s">

            <div><img src="<?php echo e(url('uploads/' . $blogData->image), false); ?>" alt="blog-image" class="img-fluid"></div>

          

            <div class="d-flex mt-4">

               <div><i class="bi bi-calendar2-week-fill"></i> <?php echo e($date, false); ?></div>

               <div class="ms-2"><i class="bi bi-person-fill"></i> <?php echo e($blogData->user_name, false); ?></div>

            </div>



            <div class="mt-4">

        <?php echo $blogData->description; ?>


            </div>

          

           </div>

           <div class="col-lg-4 col-xl-4 wow fadeInUp" data-wow-delay="0.4s">

            <h3>Categories</h3>

            <div class="cate-blog-border mt-3">

         <?php $__currentLoopData = $blogCategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blogCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

             

         <a href="<?php echo e(url('blogs/'.$blogCategory->slug), false); ?>"><div class="mt-3 d-flex justify-content-between">

             <h6><?php echo e($blogCategory->name, false); ?></h6>

             <h6><?php echo e($blogCategory->blogs_count, false); ?></h6>

           </div>

          </a>

         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

         

           </div>





           <h3 class="mt-4">Recent Post</h3>



           <?php $__currentLoopData = $recentBlog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recentBlog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

               

           <a href="#"><div class="d-flex mt-3">

                <div><img src="<?php echo e(url('uploads/' . $recentBlog->image), false); ?>" alt="blog-image" class="img-fluid recent-blog-img"></div>

               <div class="ms-2">

                <h5><?php echo e($recentBlog->title, false); ?></h5>

                <p><i class="bi bi-calendar-week-fill"></i> <?php echo e($recentBlog->created_at->format('d M Y'), false); ?></p>

               </div>

            </div>

            </a> 

           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

             



  

         

           </div>



       </div>

   </div>

</div>

<!-- ------------Blog Details End---------------------- -->



       <!--Recent Blog Start -->

       <div class="container-fluid blog py-5">

           <div class="container py-5">

               <div class="text-center mx-auto pb-5 wow fadeInUp" data-wow-delay="0.2s" style="max-width: 800px;">

                   <h4 class="text-primary">Recent Blogs</h4>

                  

               </div>

               <div class="row g-4 justify-content-center">

          <?php $__currentLoopData = $blog; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

              

    

                   <div class="col-lg-6 col-xl-4 wow fadeInUp" data-wow-delay="0.4s">

                       <div class="blog-item">

                           <div class="blog-img">

                               <img src="<?php echo e(url('uploads/' . $blog->image), false); ?>" class="img-fluid rounded-top w-100" alt="">

                               <div class="blog-categiry py-2 px-4">

                                   <span><?php echo e($blog->blogCategory['name'], false); ?></span>

                               </div>

                           </div>

                           <div class="blog-content p-4">

                               <div class="blog-comment d-flex justify-content-between mb-3">

                                   <div class="small"><span class="fa fa-user text-primary"></span> Martin.C</div>

                                   <div class="small"><span class="fa fa-calendar text-primary"></span> <?php echo e($blog->created_at->format('d M Y'), false); ?></div>

                                   <div class="small"><span class="fa fa-comment-alt text-primary"></span> 6 Comments</div>

                               </div>

                               <a href="<?php echo e(url('blog-details/'.$blog->slug), false); ?>" class="h4 d-inline-block mb-3"><?php echo e($blog->title, false); ?></a>

                               <p class="mb-3"><?php echo e($blog->short_content, false); ?></p>

                               <a href="<?php echo e(url('blog-details/'.$blog->slug), false); ?>" class="btn p-0">Read More  <i class="fa fa-arrow-right"></i></a>

                           </div>

                       </div>

                   </div>



                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

       

               </div>

           </div>

       </div>

       <!-- ---------Recent Blog End----------- -->























<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/codepino/verbalixtechnologies.com/resources/views/blog-details.blade.php ENDPATH**/ ?>