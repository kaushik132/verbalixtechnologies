
<?php $__env->startSection('main-containers'); ?>
<?php
     use Carbon\Carbon;
?>


 <!-- Header Start -->
 <div class="container-fluid bg-breadcrumb" style="background-image: url(../uploads/<?php echo e($banner['banner'], false); ?>)">
  <div class="container text-md-start text-center py-5">
      <h4 class="text-white display-4 mb-4 wow fadeInDown" data-wow-delay="0.1s">Our Blog</h4>
      <ol class="breadcrumb d-flex mb-0 wow fadeInDown" data-wow-delay="0.3s">
          <li class="breadcrumb-item"><a href="index.html">Home</a></li>
          <li class="breadcrumb-item"><a href="#">Pages</a></li>
          <li class="breadcrumb-item active text-white">Blog</li>
      </ol>    
  </div>
</div>
<!-- Header End -->


<!-- Blog Start -->
<div class="container-fluid blog py-5">
  <div class="container py-5">
      <div class="text-center mx-auto pb-5 wow fadeInUp" data-wow-delay="0.2s" style="max-width: 800px;">
          <h4 class="text-primary">From Blog</h4>
          <h1 class="display-4 mb-4">News And Updates</h1>
          <p class="mb-0">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Tenetur adipisci facilis cupiditate recusandae aperiam temporibus corporis itaque quis facere, numquam, ad culpa deserunt sint dolorem autem obcaecati, ipsam mollitia hic.
          </p>
      </div>
      <div class="row g-4 justify-content-center">


        <?php $__currentLoopData = $blogList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blogList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            
      
          <div class="col-lg-6 col-xl-4 wow fadeInUp" data-wow-delay="0.2s">
              <div class="blog-item">
                  <div class="blog-img">
                      <img src="<?php echo e(url('uploads/' . $blogList->image), false); ?>" class="img-fluid rounded-top w-100" alt="">
                      <div class="blog-categiry py-2 px-4">
                          <span><?php echo e($blogList->blogCategory['name'], false); ?></span>
                      </div>
                  </div>
                  <div class="blog-content p-4">
                      <div class="blog-comment d-flex justify-content-between mb-3">
                          <div class="small"><span class="fa fa-user text-primary"></span> Martin.C</div>
                          <div class="small"><span class="fa fa-calendar text-primary"></span>  <?php echo e($blogList->created_at->format('d M Y'), false); ?></div>
                          <div class="small"><span class="fa fa-comment-alt text-primary"></span> 6 Comments</div>
                      </div>
                      <a href="<?php echo e(url('blog-details/'.$blogList->slug), false); ?>" class="h4 d-inline-block mb-3"><?php echo e($blogList->title, false); ?></a>
                      <p class="mb-3"><?php echo e($blogList->short_content, false); ?></p>
                      <a href="<?php echo e(url('blog-details/'.$blogList->slug), false); ?>" class="btn p-0">Read More  <i class="fa fa-arrow-right"></i></a>
                  </div>
              </div>
          </div>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

      
         

       
    
      </div>
  </div>
</div>
<!-- Blog End -->






<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Chetan Singh_ICE-1411_Web Technologies\resources\views/blogs.blade.php ENDPATH**/ ?>