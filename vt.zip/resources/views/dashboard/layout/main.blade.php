@include('dashboard.layout.header')

@yield('main-containers')

@include('dashboard.layout.footer')