<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Homebanner extends Model
{
    protected $table = 'homebanner';
}
