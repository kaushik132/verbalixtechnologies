<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class HomeModify extends Model
{
    protected $table = 'home';
}
